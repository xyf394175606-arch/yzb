---
name: k12-prototype-design-system
description: Use when a K12 task creates, modifies, reviews, or migrates an interactive HTML prototype, especially when a shared shell, navigation, notes panel, modal, filter, or approved component rule must be applied.
---

# K12 Prototype Design System

Use this skill whenever a k12 task creates, modifies, reviews, or migrates an interactive HTML prototype. Treat the project files as the source of truth; do not depend on memory from another conversation.

## Required Context

Resolve the k12 project root from the current working directory or the nearest ancestor containing `AGENTS.md` and `10_高保真原型/`. Prefer project files when available. Before changing files, read:

1. `<k12-root>/AGENTS.md`
2. `<k12-root>/00_项目规则/项目总览_工作流程_v1_20260602.md`
3. `<k12-root>/00_项目规则/组件库调用规范_基础组件与业务模板_v1_20260718.md`
4. `<k12-root>/00_项目规则/原型设计规范_工作台布局与弹窗交互_v1_20260718.md`
5. `<k12-root>/10_高保真原型/高保真原型_统一工作台外壳与左右导航模板_v1_20260718.html`
6. `<k12-root>/10_高保真原型/高保真原型_组件库展示台与调用规范_v1_20260718.html`

When a project file is unavailable, use the bundled fallback resources: `references/` for rules and `assets/` for HTML templates/catalogs. Also read the current task's upstream outputs and relevant existing HTML before designing or editing.

## Task Classification

Classify the task before implementation. Use repository evidence and the current request in this order:

| Class | Signals | Required behavior |
| --- | --- | --- |
| New prototype | No target business HTML exists, or the user explicitly asks for a new page/module | Start from the unified shell template and compose approved components. |
| Existing iteration | The user asks to continue, adjust, fix, or add behavior to an existing prototype | Preserve all existing business content, flow, fields, mock data, permissions, layout, and shell. Change only the explicitly requested interaction controls and their directly related states. |
| Legacy migration | The user asks to unify, migrate, standardize, or replace the old shell/navigation | Keep the existing business center content, replace the outer shell, map old navigation into the standard hierarchy, and record exceptions. |
| Review only | The user asks to inspect, compare, or report | Do not edit files; report deviations against the rules. |

If evidence is mixed, prefer `Existing iteration` when a named HTML prototype already exists. Use `Legacy migration` only when the user explicitly requests standardization or the current outer shell conflicts with the mandatory shell. Ask one concise question only when both the target file and task type cannot be identified from the repository.

For `Existing iteration`, do not automatically apply the new shell, rearrange navigation, change page layout, rename business actions, or rewrite notes. If the requested control cannot be changed without a broader business or layout change, stop and report the conflict before editing. Treat phrases such as “统一外壳”, “迁移到新规范”, “统一左右导航”, or “替换旧版工作台” as explicit `Legacy migration` requests.

## Standard Shell

For desktop Web/backend prototypes, use four fixed regions:

- Top bar: 64px high, `#172337`, 24px horizontal padding.
- Left navigation: 238px wide, `#F8FBFF`, right border `#DDE7F2`.
- Main workspace: adaptive width, minimum 680px, `#F2F6FB`.
- Right notes panel: 310px wide, `#FFFDF0`, left border `#DDE7F2`.

Use system Chinese sans-serif text, 14px body text, 24px page titles, 11px navigation group labels, 12px child navigation and notes text, 4px spacing increments, and 8px navigation/note-card radius.

Left navigation must support grouped entries, parent/child hierarchy, current-page highlight, parent expansion, counts or short metadata, and related links. Clicking a page updates the main title, current highlight, and right notes.

Right notes must be titled `需求说明`, identify the current page/module/modal, and contain rule cards such as page goal, display scope, navigation rule, field rule, operation result, state/permission, and pending confirmation. Keep this panel separate from the business UI.

At `max-width: 1180px`, hide the notes panel and reduce the left navigation to 210px. At `max-width: 860px`, hide both side regions and render the main workspace as a single column. Record this mobile difference in the prototype explanation.

Use the template directly for new work:

`<k12-root>/10_高保真原型/高保真原型_统一工作台外壳与左右导航模板_v1_20260718.html`, or the bundled `assets/高保真原型_统一工作台外壳与左右导航模板_v1_20260718.html`.

## Existing Prototype Handling

For an existing iteration:

- Preserve all existing business requirements, flow, fields, permissions, mock data, layout, shell, and button outcomes.
- Change only the explicitly requested interaction controls and their directly related visual states.
- Reuse approved components for newly added or replaced controls without migrating unrelated controls.
- Do not rewrite the page solely to match the new template or standard shell.
- If a requested control change conflicts with existing business rules or requires a layout migration, report the conflict instead of silently changing it.

For a legacy migration:

- Keep the business UI in the main workspace.
- Map old left navigation into grouped primary/secondary entries.
- Move business rules and pending questions into the right notes panel without inventing requirements.
- Keep business modals, but align their layering, sizing, header/content/footer structure, and `取消 + 保存` default actions.
- Add a migration note to the prototype explanation covering preserved content, shell changes, and exceptions.

## Component Rules

- Compose from the approved component catalog; do not create a parallel button, input, table, filter, navigation, modal, or status style.
- Filter actions use `确认` and `重置`; do not mix `搜索`, `查询`, `应用`, and `清空条件` for equivalent actions.
- Keyword filtering is a combination of keyword input, `确认`, and `重置`; configure fields such as name or phone number from the business context.
- Date filtering supports quick ranges or a date range plus `确认` and `重置`; block an end date earlier than the start date.
- Modal sizes are small, medium, and large. Size changes content capacity only; keep the same permission, close, and footer rules.
- Configuration modals default to `取消` and `保存`; put deletion in the owning list row unless the requirement explicitly says otherwise.
- Preserve default, hover, focus, disabled, selected, and loading states. Handle empty, error, and no-permission states at page/template level.

## Output and Verification

Use project naming rules and write prototype artifacts to `10_高保真原型/`. For formal prototype work, produce the HTML and a structured prototype explanation containing background, goal, inputs, conclusions, pending questions, risks/dependencies, next steps, page/field/interaction/state/permission details, and self-check results.

Before completion:

1. Run `git diff --check`.
2. Open the HTML in a browser or local server.
3. Verify desktop three-region layout, navigation synchronization, right-note synchronization, and modal layering.
4. Verify the 1180px and 860px responsive rules when the browser supports viewport testing; otherwise document the limitation.
5. Check that no text, buttons, navigation items, or notes overlap.
6. State whether the task was classified as new, existing iteration, legacy migration, or review only.

Do not modify upstream requirements, business flow, information architecture, or data contracts unless the user explicitly requests that change; record conflicts for upstream review.
